/** Automatically generated file. DO NOT MODIFY */
package org.brickred.customui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}